module LexerGenerator.LexerTemplate where

----------------------------------------------------------------------
-- Imports
----------------------------------------------------------------------

import Control.Lens (ASetter, (.~))

----------------------------------------------------------------------
-- Type
----------------------------------------------------------------------

data LexerFile = LexerFile
  { haskellCodeHeader :: String
  , lexerName         :: String
  , tokensName        :: String
  , rules             :: [Rule]
  , haskellCodeFooter :: String
  }

data Rule = Rule
  { token :: String
  , code  :: String
  }
  
parseRule
