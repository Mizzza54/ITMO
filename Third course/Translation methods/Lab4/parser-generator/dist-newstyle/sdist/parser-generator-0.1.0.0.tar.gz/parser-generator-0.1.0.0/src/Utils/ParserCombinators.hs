{-# LANGUAGE BlockArguments #-}

module Utils.ParserCombinators where

----------------------------------------------------------------------
-- Imports
----------------------------------------------------------------------

import           Control.Applicative (empty, many, some)
import           Control.Monad       (mfilter, void)
import           Data.Char           (isSpace)
import           Utils.Base          (Annotated (..), Except (..),
                                      ExceptState (..), ParseError (..), Parser)

----------------------------------------------------------------------
-- Simple parsers combinators
----------------------------------------------------------------------

pcOk :: Parser s ()
pcOk = ES \(pos, s) -> Success (() :# (pos, s))

pcFail :: Parser s ()
pcFail = empty

pcSatisfyPredicate :: (a -> Bool) -> Parser [a] a
pcSatisfyPredicate p = mfilter p pcNext

pcNext :: ExceptState [a] a
pcNext = ES \(pos, s) ->
  case s of
    []     -> Error (ErrorAtPos pos)
    (c:cs) -> Success (c :# (pos + 1, cs))

pcSpace :: Parser String ()
pcSpace = void $ some $ pcSatisfyPredicate isSpace

pcSkipSpaces :: Parser String a -> Parser String a
pcSkipSpaces p = do
  void $ many pcSpace
  res <- p
  void $ many pcSpace
  pure res

pcEof :: Parser [a] ()
pcEof = ES \(pos, s) ->
  case s of
    [] -> Success (() :# (pos, s))
    _  -> Error (ErrorAtPos pos)

pcSatisfyChar :: Char -> Parser [Char] Char
pcSatisfyChar char = pcSatisfyPredicate (== char)

pcSatisfyString :: String -> Parser [Char] String
pcSatisfyString [] = empty
pcSatisfyString [c] = (:[]) <$> pcSatisfyChar c
pcSatisfyString (c:cs) = do
  void $ pcSatisfyChar c
  pcSatisfyString cs

pcSkipChar :: Char -> Parser [Char] ()
pcSkipChar ch = void $ pcSkipSpaces $ pcSatisfyChar ch

pcBetweenChar :: Char -> Char -> Parser [Char] Char -> Parser [Char] Char
pcBetweenChar open close parser = do
  pcSkipChar open
  res <- parser
  pcSkipChar close
  return res

