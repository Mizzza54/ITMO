module HW3.Pretty where

prettyValue :: HiValue -> Doc AnsiStyle
prettyValue = 
